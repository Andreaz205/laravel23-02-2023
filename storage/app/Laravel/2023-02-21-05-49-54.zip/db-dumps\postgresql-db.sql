--
-- PostgreSQL database dump
--

-- Dumped from database version 15.0
-- Dumped by pg_dump version 15.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admins (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.admins OWNER TO postgres;

--
-- Name: admins_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.admins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admins_id_seq OWNER TO postgres;

--
-- Name: admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.admins_id_seq OWNED BY public.admins.id;


--
-- Name: banner_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banner_images (
    id bigint NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    image_url character varying(255),
    image_path character varying(255),
    video_url character varying(255),
    html character varying(255),
    link character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    file_path character varying(255) NOT NULL
);


ALTER TABLE public.banner_images OWNER TO postgres;

--
-- Name: banner_images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.banner_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.banner_images_id_seq OWNER TO postgres;

--
-- Name: banner_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.banner_images_id_seq OWNED BY public.banner_images.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    parent_category_id bigint,
    sketch_url character varying(255),
    image_url character varying(255),
    image_path character varying(255),
    sketch_path character varying(255),
    is_published boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_id_seq OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: category_products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category_products (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    category_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.category_products OWNER TO postgres;

--
-- Name: category_products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.category_products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_products_id_seq OWNER TO postgres;

--
-- Name: category_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.category_products_id_seq OWNED BY public.category_products.id;


--
-- Name: category_variants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category_variants (
    id bigint NOT NULL,
    variant_id bigint NOT NULL,
    category_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.category_variants OWNER TO postgres;

--
-- Name: category_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.category_variants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_variants_id_seq OWNER TO postgres;

--
-- Name: category_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.category_variants_id_seq OWNED BY public.category_variants.id;


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contacts (
    id bigint NOT NULL,
    phone character varying(255) NOT NULL,
    email character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.contacts OWNER TO postgres;

--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contacts_id_seq OWNER TO postgres;

--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.failed_jobs OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.groups (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    is_visible_in_products boolean DEFAULT false NOT NULL,
    percents integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.groups OWNER TO postgres;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groups_id_seq OWNER TO postgres;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: model_has_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.model_has_permissions (
    permission_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.model_has_permissions OWNER TO postgres;

--
-- Name: model_has_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.model_has_roles (
    role_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.model_has_roles OWNER TO postgres;

--
-- Name: option_names; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.option_names (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    product_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    default_option_value_id bigint NOT NULL,
    is_color boolean DEFAULT false NOT NULL
);


ALTER TABLE public.option_names OWNER TO postgres;

--
-- Name: option_names_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.option_names_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.option_names_id_seq OWNER TO postgres;

--
-- Name: option_names_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.option_names_id_seq OWNED BY public.option_names.id;


--
-- Name: option_value_variants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.option_value_variants (
    id bigint NOT NULL,
    variant_id bigint NOT NULL,
    option_value_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.option_value_variants OWNER TO postgres;

--
-- Name: option_value_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.option_value_variants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.option_value_variants_id_seq OWNER TO postgres;

--
-- Name: option_value_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.option_value_variants_id_seq OWNED BY public.option_value_variants.id;


--
-- Name: option_values; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.option_values (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    image_url character varying(255),
    product_id bigint NOT NULL,
    option_name_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    is_default boolean DEFAULT false NOT NULL
);


ALTER TABLE public.option_values OWNER TO postgres;

--
-- Name: option_values_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.option_values_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.option_values_id_seq OWNER TO postgres;

--
-- Name: option_values_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.option_values_id_seq OWNED BY public.option_values.id;


--
-- Name: options; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.options (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    variant_id bigint NOT NULL,
    product_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.options OWNER TO postgres;

--
-- Name: options_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.options_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.options_id_seq OWNER TO postgres;

--
-- Name: options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.options_id_seq OWNED BY public.options.id;


--
-- Name: order_histories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_histories (
    id bigint NOT NULL,
    note character varying(255) NOT NULL,
    order_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.order_histories OWNER TO postgres;

--
-- Name: order_histories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_histories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_histories_id_seq OWNER TO postgres;

--
-- Name: order_histories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_histories_id_seq OWNED BY public.order_histories.id;


--
-- Name: order_variants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_variants (
    id bigint NOT NULL,
    variant_id bigint NOT NULL,
    order_id bigint NOT NULL,
    quantity integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.order_variants OWNER TO postgres;

--
-- Name: order_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_variants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_variants_id_seq OWNER TO postgres;

--
-- Name: order_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_variants_id_seq OWNED BY public.order_variants.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id bigint NOT NULL,
    delivery_date date,
    sum integer,
    delivery_price integer,
    status character varying(255) DEFAULT 'new'::character varying NOT NULL,
    is_payed boolean DEFAULT false NOT NULL,
    user_name character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    payment_variant character varying(255) NOT NULL,
    delivery_type character varying(255) NOT NULL,
    client_comment text,
    admin_comment text,
    address character varying(255) NOT NULL,
    user_id bigint,
    duty_admin_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT orders_delivery_type_check CHECK (((delivery_type)::text = ANY ((ARRAY['delivery'::character varying, 'pickup'::character varying, 'none'::character varying])::text[]))),
    CONSTRAINT orders_payment_variant_check CHECK (((payment_variant)::text = ANY ((ARRAY['cash'::character varying, 'card'::character varying, 'partials'::character varying, 'out_variant'::character varying])::text[]))),
    CONSTRAINT orders_status_check CHECK (((status)::text = ANY ((ARRAY['new'::character varying, 'preparing'::character varying, 'agreed'::character varying, 'stored'::character varying, 'delivered'::character varying, 'aborted'::character varying, 'client_enabled'::character varying, 'back'::character varying, 'back_process'::character varying])::text[])))
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: parameters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parameters (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    product_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.parameters OWNER TO postgres;

--
-- Name: parameters_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parameters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parameters_id_seq OWNER TO postgres;

--
-- Name: parameters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parameters_id_seq OWNED BY public.parameters.id;


--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_resets (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.password_resets OWNER TO postgres;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_access_tokens_id_seq OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: popular_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.popular_categories (
    id bigint NOT NULL,
    category_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.popular_categories OWNER TO postgres;

--
-- Name: popular_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.popular_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.popular_categories_id_seq OWNER TO postgres;

--
-- Name: popular_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.popular_categories_id_seq OWNED BY public.popular_categories.id;


--
-- Name: product_sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_sales (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    sale_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.product_sales OWNER TO postgres;

--
-- Name: product_sales_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_sales_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_sales_id_seq OWNER TO postgres;

--
-- Name: product_sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_sales_id_seq OWNED BY public.product_sales.id;


--
-- Name: product_variant_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_variant_images (
    id bigint NOT NULL,
    image_path character varying(255),
    image_url character varying(255),
    product_id bigint,
    variant_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    "position" integer
);


ALTER TABLE public.product_variant_images OWNER TO postgres;

--
-- Name: product_variant_images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_variant_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_variant_images_id_seq OWNER TO postgres;

--
-- Name: product_variant_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_variant_images_id_seq OWNED BY public.product_variant_images.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    length integer,
    width integer,
    height integer,
    allow_sales boolean DEFAULT false NOT NULL,
    weight character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: related_variants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.related_variants (
    id bigint NOT NULL,
    parent_variant_id bigint NOT NULL,
    related_variant_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.related_variants OWNER TO postgres;

--
-- Name: related_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.related_variants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.related_variants_id_seq OWNER TO postgres;

--
-- Name: related_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.related_variants_id_seq OWNED BY public.related_variants.id;


--
-- Name: review_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review_images (
    id bigint NOT NULL,
    image_path character varying(255) NOT NULL,
    image_url character varying(255) NOT NULL,
    review_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.review_images OWNER TO postgres;

--
-- Name: review_images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.review_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.review_images_id_seq OWNER TO postgres;

--
-- Name: review_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.review_images_id_seq OWNED BY public.review_images.id;


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reviews (
    id bigint NOT NULL,
    content character varying(255) NOT NULL,
    published boolean DEFAULT false NOT NULL,
    mark character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    user_id bigint,
    variant_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    is_viewed boolean DEFAULT false NOT NULL,
    CONSTRAINT reviews_mark_check CHECK (((mark)::text = ANY ((ARRAY['1'::character varying, '2'::character varying, '3'::character varying, '4'::character varying, '5'::character varying])::text[])))
);


ALTER TABLE public.reviews OWNER TO postgres;

--
-- Name: reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reviews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reviews_id_seq OWNER TO postgres;

--
-- Name: reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reviews_id_seq OWNED BY public.reviews.id;


--
-- Name: rich_contents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rich_contents (
    id bigint NOT NULL,
    json text,
    html text,
    ozon_code text,
    variant_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.rich_contents OWNER TO postgres;

--
-- Name: rich_contents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rich_contents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rich_contents_id_seq OWNER TO postgres;

--
-- Name: rich_contents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rich_contents_id_seq OWNED BY public.rich_contents.id;


--
-- Name: rich_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rich_images (
    id bigint NOT NULL,
    image_path character varying(255) NOT NULL,
    image_url character varying(255) NOT NULL,
    rich_content_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.rich_images OWNER TO postgres;

--
-- Name: rich_images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rich_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rich_images_id_seq OWNER TO postgres;

--
-- Name: rich_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rich_images_id_seq OWNED BY public.rich_images.id;


--
-- Name: role_has_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_has_permissions (
    permission_id bigint NOT NULL,
    role_id bigint NOT NULL,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.role_has_permissions OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: room_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.room_categories (
    id bigint NOT NULL,
    room_id bigint NOT NULL,
    category_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.room_categories OWNER TO postgres;

--
-- Name: room_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.room_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.room_categories_id_seq OWNER TO postgres;

--
-- Name: room_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.room_categories_id_seq OWNED BY public.room_categories.id;


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rooms (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    image_url character varying(255),
    image_path character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.rooms OWNER TO postgres;

--
-- Name: rooms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rooms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rooms_id_seq OWNER TO postgres;

--
-- Name: rooms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rooms_id_seq OWNED BY public.rooms.id;


--
-- Name: sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    image_url character varying(255),
    image_path character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.sales OWNER TO postgres;

--
-- Name: sales_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sales_id_seq OWNER TO postgres;

--
-- Name: sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_id_seq OWNED BY public.sales.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    group_id bigint,
    kind character varying(255) DEFAULT 'single'::character varying NOT NULL,
    CONSTRAINT users_kind_check CHECK (((kind)::text = ANY ((ARRAY['single'::character varying, 'organization'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: variants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.variants (
    id bigint NOT NULL,
    code character varying(255),
    price integer,
    old_price integer,
    purchase_price integer,
    quantity integer,
    views integer DEFAULT 0 NOT NULL,
    product_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.variants OWNER TO postgres;

--
-- Name: variants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.variants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.variants_id_seq OWNER TO postgres;

--
-- Name: variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.variants_id_seq OWNED BY public.variants.id;


--
-- Name: admins id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins ALTER COLUMN id SET DEFAULT nextval('public.admins_id_seq'::regclass);


--
-- Name: banner_images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banner_images ALTER COLUMN id SET DEFAULT nextval('public.banner_images_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: category_products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_products ALTER COLUMN id SET DEFAULT nextval('public.category_products_id_seq'::regclass);


--
-- Name: category_variants id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_variants ALTER COLUMN id SET DEFAULT nextval('public.category_variants_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: option_names id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option_names ALTER COLUMN id SET DEFAULT nextval('public.option_names_id_seq'::regclass);


--
-- Name: option_value_variants id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option_value_variants ALTER COLUMN id SET DEFAULT nextval('public.option_value_variants_id_seq'::regclass);


--
-- Name: option_values id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option_values ALTER COLUMN id SET DEFAULT nextval('public.option_values_id_seq'::regclass);


--
-- Name: options id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.options ALTER COLUMN id SET DEFAULT nextval('public.options_id_seq'::regclass);


--
-- Name: order_histories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_histories ALTER COLUMN id SET DEFAULT nextval('public.order_histories_id_seq'::regclass);


--
-- Name: order_variants id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_variants ALTER COLUMN id SET DEFAULT nextval('public.order_variants_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: parameters id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parameters ALTER COLUMN id SET DEFAULT nextval('public.parameters_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: popular_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.popular_categories ALTER COLUMN id SET DEFAULT nextval('public.popular_categories_id_seq'::regclass);


--
-- Name: product_sales id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_sales ALTER COLUMN id SET DEFAULT nextval('public.product_sales_id_seq'::regclass);


--
-- Name: product_variant_images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_variant_images ALTER COLUMN id SET DEFAULT nextval('public.product_variant_images_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: related_variants id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.related_variants ALTER COLUMN id SET DEFAULT nextval('public.related_variants_id_seq'::regclass);


--
-- Name: review_images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_images ALTER COLUMN id SET DEFAULT nextval('public.review_images_id_seq'::regclass);


--
-- Name: reviews id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews ALTER COLUMN id SET DEFAULT nextval('public.reviews_id_seq'::regclass);


--
-- Name: rich_contents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rich_contents ALTER COLUMN id SET DEFAULT nextval('public.rich_contents_id_seq'::regclass);


--
-- Name: rich_images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rich_images ALTER COLUMN id SET DEFAULT nextval('public.rich_images_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: room_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_categories ALTER COLUMN id SET DEFAULT nextval('public.room_categories_id_seq'::regclass);


--
-- Name: rooms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms ALTER COLUMN id SET DEFAULT nextval('public.rooms_id_seq'::regclass);


--
-- Name: sales id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales ALTER COLUMN id SET DEFAULT nextval('public.sales_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: variants id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.variants ALTER COLUMN id SET DEFAULT nextval('public.variants_id_seq'::regclass);


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admins (id, name, email, email_verified_at, password, remember_token, created_at, updated_at, deleted_at) FROM stdin;
1	Super Admin	admin@mail.ru	2023-02-20 04:28:18	$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	PzeckMkJDg	2023-02-20 04:28:18	2023-02-20 04:28:18	\N
2	Example User	user@mail.ru	2023-02-20 04:28:18	$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	yFbzGMSPeH	2023-02-20 04:28:18	2023-02-20 04:28:18	\N
\.


--
-- Data for Name: banner_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banner_images (id, "position", image_url, image_path, video_url, html, link, created_at, updated_at, deleted_at, file_path) FROM stdin;
26	0	http://127.0.0.1:8000/storage/images/1ed07a5ed31bec41244b88d56c0cc1dd.png	\N	\N	\N	\N	2023-02-21 05:41:42	2023-02-21 05:41:58	\N	images/1ed07a5ed31bec41244b88d56c0cc1dd.png
25	1	http://127.0.0.1:8000/storage/images/27610b131657eb430d886936db14d3d3.png	\N	\N	\N	\N	2023-02-21 05:27:21	2023-02-21 05:41:58	\N	images/27610b131657eb430d886936db14d3d3.png
24	5	\N	\N	http://127.0.0.1:8000/storage/images/5751e521e50541ba11da1de6b7e3d34a.mp4	\N	\N	2023-02-21 05:18:08	2023-02-21 05:18:36	2023-02-21 05:18:36	images/5751e521e50541ba11da1de6b7e3d34a.mp4
23	4	\N	\N	http://127.0.0.1:8000/storage/images/dd23c9f6e3935436e71adee419dca796.mp4	\N	\N	2023-02-21 05:17:56	2023-02-21 05:18:37	2023-02-21 05:18:37	images/dd23c9f6e3935436e71adee419dca796.mp4
22	3	http://127.0.0.1:8000/storage/images/fdddd8c0d03f9c2b6a93f87d9bdeb0a5.png	\N	\N	\N	\N	2023-02-21 05:16:00	2023-02-21 05:18:39	2023-02-21 05:18:39	images/fdddd8c0d03f9c2b6a93f87d9bdeb0a5.png
20	2	\N	\N	http://127.0.0.1:8000/storage/images/558f4ac92b1e1781fe827353856b8a66.mp4	\N	\N	2023-02-21 05:14:57	2023-02-21 05:41:58	\N	images/558f4ac92b1e1781fe827353856b8a66.mp4
21	3	http://127.0.0.1:8000/storage/images/4d0e0f6d654728d9186bbaba1ddd143b.gif	\N	\N	\N	\N	2023-02-21 05:15:50	2023-02-21 05:41:58	\N	images/4d0e0f6d654728d9186bbaba1ddd143b.gif
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, parent_category_id, sketch_url, image_url, image_path, sketch_path, is_published, created_at, updated_at, deleted_at) FROM stdin;
1	Диваны	\N	\N	\N	\N	\N	f	2023-02-20 05:59:29	2023-02-20 05:59:29	\N
2	Кресла	\N	\N	\N	\N	\N	f	2023-02-20 05:59:38	2023-02-20 05:59:38	\N
\.


--
-- Data for Name: category_products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category_products (id, product_id, category_id, created_at, updated_at, deleted_at) FROM stdin;
1	1	1	2023-02-20 09:08:44	2023-02-20 09:08:46	2023-02-20 09:08:46
2	1	2	2023-02-20 09:08:49	2023-02-20 09:08:51	2023-02-20 09:08:51
\.


--
-- Data for Name: category_variants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category_variants (id, variant_id, category_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contacts (id, phone, email, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.groups (id, title, created_at, updated_at, deleted_at, is_visible_in_products, percents) FROM stdin;
2	Оптовики30	2023-02-20 08:39:14	2023-02-20 08:39:25	\N	t	30
1	Оптовики20	2023-02-20 07:30:22	2023-02-20 08:39:44	\N	t	20
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	2014_10_12_000000_create_users_table	1
2	2014_10_12_100000_create_password_resets_table	1
3	2019_08_19_000000_create_failed_jobs_table	1
4	2019_12_14_000001_create_personal_access_tokens_table	1
5	2021_02_09_141435_create_contacts_table	1
6	2021_02_09_144759_create_admins_table	1
7	2021_02_11_121639_create_products_table	1
8	2021_02_11_122145_create_variants_table	1
9	2021_11_14_040603_create_permission_tables	1
10	2022_11_11_055650_create_product_variant_images_table	1
11	2022_11_14_043940_create_option_names_table	1
12	2022_11_14_102723_create_option_values_table	1
13	2022_11_30_102724_add_default_option_value_id_to_option_names_table	1
14	2022_12_07_070034_create_option_value_variants_table	1
15	2022_12_12_042508_create_sessions_table	1
16	2022_12_13_051447_create_categories_table	1
17	2022_12_14_065658_create_category_products_table	1
18	2022_12_15_060409_create_parameters_table	1
19	2022_12_20_082500_create_category_variants_table	1
20	2022_12_29_103512_create_related_variants_table	1
21	2022_12_30_062445_create_reviews_table	1
22	2023_01_08_160500_create_orders_table	1
23	2023_01_08_161951_create_order_variants_table	1
24	2023_01_12_114956_create_popular_categories_table	1
25	2023_01_13_110857_create_review_images_table	1
26	2023_01_20_091105_create_sales_table	1
27	2023_01_20_091719_create_product_sales_table	1
28	2023_01_25_110311_create_rich_contents_table	1
29	2023_01_25_110318_create_rich_images_table	1
30	2023_01_27_125834_create_rooms_table	1
31	2023_01_30_124004_create_groups_table	1
32	2023_01_30_124945_create_order_histories_table	1
33	2023_01_30_142717_create_room_categories_table	1
34	2023_01_30_142817_add_group_id_column_to_users_table	1
35	2023_02_08_124017_create_banner_images_table	1
36	2023_02_11_160146_create_options_table	1
37	2023_02_13_105731_add_is_default_column_to_option_values_table	1
38	2023_02_14_145639_add_position_column_to_product_variant_images	1
39	2023_02_18_110234_add_kind_column_to_users_table	1
40	2023_02_18_114554_add_is_viewed_column_to_reviews_table	1
41	2023_02_18_132633_add_is_visible_in_products_and_percents_columns_to_groups_table	1
43	2023_02_20_094742_add_is_color_column_to_option_names_table	2
45	2023_02_21_041626_make_position_default_in_banner_images_table	3
47	2023_02_21_042017_add_file_path_column_to_banner_images_table	4
\.


--
-- Data for Name: model_has_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.model_has_permissions (permission_id, model_type, model_id, deleted_at) FROM stdin;
\.


--
-- Data for Name: model_has_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.model_has_roles (role_id, model_type, model_id, deleted_at) FROM stdin;
1	App\\Models\\Admin	1	\N
\.


--
-- Data for Name: option_names; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.option_names (id, title, product_id, created_at, updated_at, deleted_at, default_option_value_id, is_color) FROM stdin;
15	Наполнение	1	2023-02-20 07:16:18	2023-02-20 09:58:26	\N	19	f
13	Ткань	1	2023-02-20 07:16:18	2023-02-20 10:10:40	\N	17	f
14	Цвет	1	2023-02-20 07:16:18	2023-02-20 10:10:40	\N	18	t
\.


--
-- Data for Name: option_value_variants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.option_value_variants (id, variant_id, option_value_id, created_at, updated_at, deleted_at) FROM stdin;
45	22	21	2023-02-20 07:25:01	2023-02-20 07:26:23	2023-02-20 07:26:23
46	22	20	2023-02-20 07:26:23	2023-02-20 07:26:54	2023-02-20 07:26:54
47	22	18	2023-02-20 07:26:54	2023-02-20 07:35:56	2023-02-20 07:35:56
48	22	21	2023-02-20 07:35:56	2023-02-20 08:05:23	2023-02-20 08:05:23
28	18	18	2023-02-20 07:16:18	2023-02-20 08:07:26	2023-02-20 08:07:26
49	22	20	2023-02-20 08:05:23	2023-02-20 08:07:53	2023-02-20 08:07:53
51	22	21	2023-02-20 08:07:53	2023-02-20 08:08:04	2023-02-20 08:08:04
52	22	18	2023-02-20 08:08:04	2023-02-20 08:16:24	2023-02-20 08:16:24
54	23	17	2023-02-20 08:16:40	2023-02-20 08:16:40	\N
56	23	19	2023-02-20 08:16:40	2023-02-20 08:16:40	\N
50	18	21	2023-02-20 08:07:26	2023-02-20 08:21:49	2023-02-20 08:21:49
55	23	18	2023-02-20 08:16:40	2023-02-20 08:22:44	2023-02-20 08:22:44
58	23	24	2023-02-20 08:22:44	2023-02-20 08:26:19	2023-02-20 08:26:19
57	18	23	2023-02-20 08:21:49	2023-02-20 08:27:32	2023-02-20 08:27:32
60	18	26	2023-02-20 08:27:32	2023-02-20 08:28:53	2023-02-20 08:28:53
61	18	27	2023-02-20 08:28:53	2023-02-20 08:29:48	2023-02-20 08:29:48
62	18	28	2023-02-20 08:29:48	2023-02-20 08:31:03	2023-02-20 08:31:03
63	18	29	2023-02-20 08:31:03	2023-02-20 08:31:35	2023-02-20 08:31:35
59	23	25	2023-02-20 08:26:19	2023-02-20 08:33:17	2023-02-20 08:33:17
65	23	31	2023-02-20 08:33:17	2023-02-20 08:33:39	2023-02-20 08:33:39
53	22	22	2023-02-20 08:16:24	2023-02-20 08:33:45	2023-02-20 08:33:45
67	22	23	2023-02-20 08:33:45	2023-02-20 08:33:45	\N
30	19	20	2023-02-20 07:16:29	2023-02-20 08:34:25	2023-02-20 08:34:25
27	18	17	2023-02-20 07:16:18	2023-02-20 07:16:18	\N
31	19	17	2023-02-20 07:16:29	2023-02-20 07:16:29	\N
32	19	19	2023-02-20 07:16:29	2023-02-20 07:16:29	\N
33	20	21	2023-02-20 07:16:40	2023-02-20 07:16:56	2023-02-20 07:16:56
34	20	17	2023-02-20 07:16:40	2023-02-20 07:18:49	2023-02-20 07:18:49
35	20	19	2023-02-20 07:16:40	2023-02-20 07:18:49	2023-02-20 07:18:49
36	20	20	2023-02-20 07:16:56	2023-02-20 07:18:49	2023-02-20 07:18:49
37	21	17	2023-02-20 07:18:55	2023-02-20 07:20:09	2023-02-20 07:20:09
38	21	21	2023-02-20 07:18:55	2023-02-20 07:20:09	2023-02-20 07:20:09
39	21	19	2023-02-20 07:18:55	2023-02-20 07:20:09	2023-02-20 07:20:09
40	21	20	2023-02-20 07:19:40	2023-02-20 07:20:09	2023-02-20 07:20:09
41	22	17	2023-02-20 07:20:12	2023-02-20 07:20:12	\N
43	22	19	2023-02-20 07:20:12	2023-02-20 07:20:12	\N
42	22	21	2023-02-20 07:20:12	2023-02-20 07:20:17	2023-02-20 07:20:17
44	22	20	2023-02-20 07:20:17	2023-02-20 07:25:01	2023-02-20 07:25:01
68	19	22	2023-02-20 08:34:25	2023-02-20 08:37:25	2023-02-20 08:37:25
69	19	23	2023-02-20 08:37:25	2023-02-20 08:37:35	2023-02-20 08:37:35
70	19	24	2023-02-20 08:37:35	2023-02-20 08:37:35	\N
66	23	32	2023-02-20 08:33:39	2023-02-20 08:43:29	2023-02-20 08:43:29
64	18	30	2023-02-20 08:31:35	2023-02-20 08:45:15	2023-02-20 08:45:15
71	23	30	2023-02-20 08:43:29	2023-02-20 08:48:38	2023-02-20 08:48:38
73	23	28	2023-02-20 08:48:38	2023-02-20 08:48:38	\N
29	18	19	2023-02-20 07:16:18	2023-02-20 08:48:52	2023-02-20 08:48:52
74	18	33	2023-02-20 08:48:52	2023-02-20 08:48:52	\N
72	18	22	2023-02-20 08:45:15	2023-02-20 09:04:04	2023-02-20 09:04:04
75	18	23	2023-02-20 09:04:04	2023-02-20 09:04:14	2023-02-20 09:04:14
76	18	34	2023-02-20 09:04:14	2023-02-20 09:04:14	\N
\.


--
-- Data for Name: option_values; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.option_values (id, title, image_url, product_id, option_name_id, created_at, updated_at, deleted_at, is_default) FROM stdin;
17	Нелла	\N	1	13	2023-02-20 07:16:18	2023-02-20 07:16:18	\N	f
18	1	\N	1	14	2023-02-20 07:16:18	2023-02-20 07:16:18	\N	f
19	ППУ	\N	1	15	2023-02-20 07:16:18	2023-02-20 07:16:18	\N	f
20	2	\N	1	14	2023-02-20 07:16:29	2023-02-20 07:16:29	\N	f
21	3	\N	1	14	2023-02-20 07:16:40	2023-02-20 07:16:40	\N	f
22	4	\N	1	14	2023-02-20 08:16:24	2023-02-20 08:16:24	\N	f
23	5	\N	1	14	2023-02-20 08:21:49	2023-02-20 08:21:49	\N	f
24	6	\N	1	14	2023-02-20 08:22:44	2023-02-20 08:22:44	\N	f
25	8	\N	1	14	2023-02-20 08:26:19	2023-02-20 08:26:19	\N	f
26	9	\N	1	14	2023-02-20 08:27:32	2023-02-20 08:27:32	\N	f
27	10	\N	1	14	2023-02-20 08:28:53	2023-02-20 08:28:53	\N	f
28	11	\N	1	14	2023-02-20 08:29:48	2023-02-20 08:29:48	\N	f
29	12	\N	1	14	2023-02-20 08:31:03	2023-02-20 08:31:03	\N	f
30	13	\N	1	14	2023-02-20 08:31:35	2023-02-20 08:31:35	\N	f
31	0	\N	1	14	2023-02-20 08:33:17	2023-02-20 08:33:17	\N	f
32	14	\N	1	14	2023-02-20 08:33:39	2023-02-20 08:33:39	\N	f
33	НПБ	\N	1	15	2023-02-20 08:48:52	2023-02-20 08:48:52	\N	f
34	17	\N	1	14	2023-02-20 09:04:14	2023-02-20 09:04:14	\N	f
\.


--
-- Data for Name: options; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.options (id, title, value, variant_id, product_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_histories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_histories (id, note, order_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_variants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_variants (id, variant_id, order_id, quantity, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, delivery_date, sum, delivery_price, status, is_payed, user_name, phone, email, payment_variant, delivery_type, client_comment, admin_comment, address, user_id, duty_admin_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: parameters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parameters (id, title, value, product_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_resets (email, token, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (id, name, guard_name, created_at, updated_at, deleted_at) FROM stdin;
1	permission list	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
2	permission create	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
3	permission edit	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
4	permission delete	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
5	role list	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
6	role create	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
7	role edit	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
8	role delete	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
9	user list	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
10	user create	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
11	user edit	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
12	user delete	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
13	contact list	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
14	contact create	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
15	contact edit	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
16	contact delete	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
17	admin list	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
18	admin create	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
19	admin edit	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
20	admin delete	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: popular_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.popular_categories (id, category_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: product_sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_sales (id, product_id, sale_id, created_at, updated_at, deleted_at) FROM stdin;
1	1	1	2023-02-20 11:07:25	2023-02-20 11:07:25	\N
\.


--
-- Data for Name: product_variant_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_variant_images (id, image_path, image_url, product_id, variant_id, created_at, updated_at, deleted_at, "position") FROM stdin;
8	images/121948c223c2a11eae9c2becdd035545.jpg	http://127.0.0.1:8000/storage/images/121948c223c2a11eae9c2becdd035545.jpg	1	18	2023-02-20 05:59:01	2023-02-20 09:08:56	\N	2
9	images/89521905955f2df6a46b2140bfb88e7e.jpg	http://127.0.0.1:8000/storage/images/89521905955f2df6a46b2140bfb88e7e.jpg	1	23	2023-02-20 05:59:02	2023-02-20 09:08:56	\N	3
6	images/14310bdba803afc4339e9b3bb6c47797.jpg	http://127.0.0.1:8000/storage/images/14310bdba803afc4339e9b3bb6c47797.jpg	1	22	2023-02-20 05:59:01	2023-02-20 09:09:02	\N	0
11	images/e6e585567513268f5abb1a09938ddcf0.jpg	http://127.0.0.1:8000/storage/images/e6e585567513268f5abb1a09938ddcf0.jpg	1	19	2023-02-20 05:59:02	2023-02-20 09:09:02	\N	1
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, title, length, width, height, allow_sales, weight, created_at, updated_at, deleted_at) FROM stdin;
1	Бали	\N	\N	\N	f	\N	2023-02-20 04:28:35	2023-02-20 04:28:35	\N
\.


--
-- Data for Name: related_variants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.related_variants (id, parent_variant_id, related_variant_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: review_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review_images (id, image_path, image_url, review_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (id, content, published, mark, name, user_id, variant_id, created_at, updated_at, deleted_at, is_viewed) FROM stdin;
\.


--
-- Data for Name: rich_contents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rich_contents (id, json, html, ozon_code, variant_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: rich_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rich_images (id, image_path, image_url, rich_content_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: role_has_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_has_permissions (permission_id, role_id, deleted_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, guard_name, created_at, updated_at, deleted_at) FROM stdin;
1	super-admin	admin	2023-02-20 04:28:17	2023-02-20 04:28:17	\N
\.


--
-- Data for Name: room_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.room_categories (id, room_id, category_id, created_at, updated_at, deleted_at) FROM stdin;
1	1	1	2023-02-20 06:00:13	2023-02-20 06:00:13	\N
\.


--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rooms (id, title, image_url, image_path, created_at, updated_at, deleted_at) FROM stdin;
1	Спальня	http://127.0.0.1:8000/storage/images/493f8cc8d5a4dfdc8b847816d29c9051.jpg	images/493f8cc8d5a4dfdc8b847816d29c9051.jpg	2023-02-20 06:00:07	2023-02-20 06:00:07	\N
2	Прихожая	http://127.0.0.1:8000/storage/images/084d94b35fb3e5c16b34b86ace185e61.jpg	images/084d94b35fb3e5c16b34b86ace185e61.jpg	2023-02-20 06:01:00	2023-02-20 06:01:00	\N
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales (id, title, is_public, image_url, image_path, created_at, updated_at, deleted_at) FROM stdin;
1	Весенняя распродажа	t	http://127.0.0.1:8000/storage/images/95429804b9b20280a056729ad7313ca8.jpg	images/95429804b9b20280a056729ad7313ca8.jpg	2023-02-20 11:07:16	2023-02-20 11:07:53	\N
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity, deleted_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at, deleted_at, group_id, kind) FROM stdin;
1	user	user@mail.ru	\N	$2y$10$pZJh/fIDeEeIr.amAHF1hOW8/BLk80uNTsXQwlyYywVI.J8laruw.	\N	2023-02-20 07:30:06	2023-02-20 07:30:06	\N	\N	single
\.


--
-- Data for Name: variants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.variants (id, code, price, old_price, purchase_price, quantity, views, product_id, created_at, updated_at, deleted_at) FROM stdin;
19	\N	\N	\N	\N	\N	0	1	2023-02-20 07:16:29	2023-02-20 07:16:29	\N
20	\N	\N	\N	\N	\N	0	1	2023-02-20 07:16:40	2023-02-20 07:18:49	2023-02-20 07:18:49
21	\N	\N	\N	\N	\N	0	1	2023-02-20 07:18:55	2023-02-20 07:20:09	2023-02-20 07:20:09
22	\N	\N	\N	\N	\N	0	1	2023-02-20 07:20:12	2023-02-20 07:20:12	\N
23	\N	\N	\N	\N	\N	0	1	2023-02-20 08:16:40	2023-02-20 08:16:40	\N
18	—	500	\N	\N	\N	0	1	2023-02-20 07:16:18	2023-02-20 09:31:33	\N
\.


--
-- Name: admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admins_id_seq', 2, true);


--
-- Name: banner_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.banner_images_id_seq', 26, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_id_seq', 2, true);


--
-- Name: category_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.category_products_id_seq', 2, true);


--
-- Name: category_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.category_variants_id_seq', 1, false);


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contacts_id_seq', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.groups_id_seq', 2, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 47, true);


--
-- Name: option_names_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.option_names_id_seq', 15, true);


--
-- Name: option_value_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.option_value_variants_id_seq', 76, true);


--
-- Name: option_values_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.option_values_id_seq', 34, true);


--
-- Name: options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.options_id_seq', 1, false);


--
-- Name: order_histories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_histories_id_seq', 1, false);


--
-- Name: order_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_variants_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, false);


--
-- Name: parameters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parameters_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.permissions_id_seq', 20, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- Name: popular_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.popular_categories_id_seq', 1, false);


--
-- Name: product_sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_sales_id_seq', 1, true);


--
-- Name: product_variant_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_variant_images_id_seq', 11, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_id_seq', 1, true);


--
-- Name: related_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.related_variants_id_seq', 1, false);


--
-- Name: review_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.review_images_id_seq', 1, false);


--
-- Name: reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reviews_id_seq', 1, false);


--
-- Name: rich_contents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rich_contents_id_seq', 1, false);


--
-- Name: rich_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rich_images_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, true);


--
-- Name: room_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.room_categories_id_seq', 1, true);


--
-- Name: rooms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rooms_id_seq', 2, true);


--
-- Name: sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.variants_id_seq', 23, true);


--
-- Name: admins admins_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_email_unique UNIQUE (email);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- Name: banner_images banner_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banner_images
    ADD CONSTRAINT banner_images_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: category_products category_products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_products
    ADD CONSTRAINT category_products_pkey PRIMARY KEY (id);


--
-- Name: category_variants category_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_variants
    ADD CONSTRAINT category_variants_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: model_has_permissions model_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_pkey PRIMARY KEY (permission_id, model_id, model_type);


--
-- Name: model_has_roles model_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_pkey PRIMARY KEY (role_id, model_id, model_type);


--
-- Name: option_names option_names_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option_names
    ADD CONSTRAINT option_names_pkey PRIMARY KEY (id);


--
-- Name: option_value_variants option_value_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option_value_variants
    ADD CONSTRAINT option_value_variants_pkey PRIMARY KEY (id);


--
-- Name: option_values option_values_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option_values
    ADD CONSTRAINT option_values_pkey PRIMARY KEY (id);


--
-- Name: options options_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.options
    ADD CONSTRAINT options_pkey PRIMARY KEY (id);


--
-- Name: order_histories order_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_histories
    ADD CONSTRAINT order_histories_pkey PRIMARY KEY (id);


--
-- Name: order_variants order_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_variants
    ADD CONSTRAINT order_variants_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: parameters parameters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parameters
    ADD CONSTRAINT parameters_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: popular_categories popular_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.popular_categories
    ADD CONSTRAINT popular_categories_pkey PRIMARY KEY (id);


--
-- Name: product_sales product_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_sales
    ADD CONSTRAINT product_sales_pkey PRIMARY KEY (id);


--
-- Name: product_variant_images product_variant_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_variant_images
    ADD CONSTRAINT product_variant_images_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: related_variants related_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.related_variants
    ADD CONSTRAINT related_variants_pkey PRIMARY KEY (id);


--
-- Name: review_images review_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_images
    ADD CONSTRAINT review_images_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: rich_contents rich_contents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rich_contents
    ADD CONSTRAINT rich_contents_pkey PRIMARY KEY (id);


--
-- Name: rich_images rich_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rich_images
    ADD CONSTRAINT rich_images_pkey PRIMARY KEY (id);


--
-- Name: role_has_permissions role_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_pkey PRIMARY KEY (permission_id, role_id);


--
-- Name: roles roles_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: room_categories room_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_categories
    ADD CONSTRAINT room_categories_pkey PRIMARY KEY (id);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: variants variants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.variants
    ADD CONSTRAINT variants_pkey PRIMARY KEY (id);


--
-- Name: category_products_category_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX category_products_category_id_index ON public.category_products USING btree (category_id);


--
-- Name: category_products_product_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX category_products_product_id_index ON public.category_products USING btree (product_id);


--
-- Name: category_variants_category_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX category_variants_category_id_index ON public.category_variants USING btree (category_id);


--
-- Name: category_variants_variant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX category_variants_variant_id_index ON public.category_variants USING btree (variant_id);


--
-- Name: model_has_permissions_model_id_model_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX model_has_permissions_model_id_model_type_index ON public.model_has_permissions USING btree (model_id, model_type);


--
-- Name: model_has_roles_model_id_model_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX model_has_roles_model_id_model_type_index ON public.model_has_roles USING btree (model_id, model_type);


--
-- Name: option_names_default_option_value_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX option_names_default_option_value_id_index ON public.option_names USING btree (default_option_value_id);


--
-- Name: option_names_product_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX option_names_product_id_index ON public.option_names USING btree (product_id);


--
-- Name: option_value_variants_option_value_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX option_value_variants_option_value_id_index ON public.option_value_variants USING btree (option_value_id);


--
-- Name: option_value_variants_variant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX option_value_variants_variant_id_index ON public.option_value_variants USING btree (variant_id);


--
-- Name: option_values_product_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX option_values_product_id_index ON public.option_values USING btree (product_id);


--
-- Name: options_product_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX options_product_id_index ON public.options USING btree (product_id);


--
-- Name: options_variant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX options_variant_id_index ON public.options USING btree (variant_id);


--
-- Name: order_histories_order_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_histories_order_id_index ON public.order_histories USING btree (order_id);


--
-- Name: order_variants_order_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_variants_order_id_index ON public.order_variants USING btree (order_id);


--
-- Name: order_variants_variant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_variants_variant_id_index ON public.order_variants USING btree (variant_id);


--
-- Name: orders_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orders_user_id_index ON public.orders USING btree (user_id);


--
-- Name: parameters_product_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parameters_product_id_index ON public.parameters USING btree (product_id);


--
-- Name: password_resets_email_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX password_resets_email_index ON public.password_resets USING btree (email);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: product_sales_product_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_sales_product_id_index ON public.product_sales USING btree (product_id);


--
-- Name: product_sales_sale_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_sales_sale_id_index ON public.product_sales USING btree (sale_id);


--
-- Name: product_variant_images_product_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_variant_images_product_id_index ON public.product_variant_images USING btree (product_id);


--
-- Name: product_variant_images_variant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_variant_images_variant_id_index ON public.product_variant_images USING btree (variant_id);


--
-- Name: related_variants_parent_variant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX related_variants_parent_variant_id_index ON public.related_variants USING btree (parent_variant_id);


--
-- Name: related_variants_related_variant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX related_variants_related_variant_id_index ON public.related_variants USING btree (related_variant_id);


--
-- Name: reviews_variant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reviews_variant_id_index ON public.reviews USING btree (variant_id);


--
-- Name: rich_contents_variant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rich_contents_variant_id_index ON public.rich_contents USING btree (variant_id);


--
-- Name: room_categories_category_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX room_categories_category_id_index ON public.room_categories USING btree (category_id);


--
-- Name: room_categories_room_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX room_categories_room_id_index ON public.room_categories USING btree (room_id);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: variants_product_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX variants_product_id_index ON public.variants USING btree (product_id);


--
-- Name: categories categories_parent_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_parent_category_id_foreign FOREIGN KEY (parent_category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: category_products category_products_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_products
    ADD CONSTRAINT category_products_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: category_products category_products_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_products
    ADD CONSTRAINT category_products_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: category_variants category_variants_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_variants
    ADD CONSTRAINT category_variants_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: category_variants category_variants_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_variants
    ADD CONSTRAINT category_variants_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.variants(id) ON DELETE CASCADE;


--
-- Name: model_has_permissions model_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: model_has_roles model_has_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: option_names option_names_default_option_value_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option_names
    ADD CONSTRAINT option_names_default_option_value_id_foreign FOREIGN KEY (default_option_value_id) REFERENCES public.option_values(id) ON DELETE CASCADE;


--
-- Name: option_names option_names_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option_names
    ADD CONSTRAINT option_names_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: option_value_variants option_value_variants_option_value_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option_value_variants
    ADD CONSTRAINT option_value_variants_option_value_id_foreign FOREIGN KEY (option_value_id) REFERENCES public.option_values(id) ON DELETE CASCADE;


--
-- Name: option_value_variants option_value_variants_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option_value_variants
    ADD CONSTRAINT option_value_variants_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.variants(id) ON DELETE CASCADE;


--
-- Name: option_values option_values_option_name_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option_values
    ADD CONSTRAINT option_values_option_name_id_foreign FOREIGN KEY (option_name_id) REFERENCES public.option_names(id) ON DELETE CASCADE;


--
-- Name: option_values option_values_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.option_values
    ADD CONSTRAINT option_values_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: options options_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.options
    ADD CONSTRAINT options_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: options options_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.options
    ADD CONSTRAINT options_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.variants(id) ON DELETE CASCADE;


--
-- Name: order_histories order_histories_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_histories
    ADD CONSTRAINT order_histories_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_variants order_variants_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_variants
    ADD CONSTRAINT order_variants_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_variants order_variants_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_variants
    ADD CONSTRAINT order_variants_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.variants(id) ON DELETE CASCADE;


--
-- Name: orders orders_duty_admin_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_duty_admin_id_foreign FOREIGN KEY (duty_admin_id) REFERENCES public.admins(id) ON DELETE CASCADE;


--
-- Name: orders orders_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: parameters parameters_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parameters
    ADD CONSTRAINT parameters_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: popular_categories popular_categories_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.popular_categories
    ADD CONSTRAINT popular_categories_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: product_sales product_sales_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_sales
    ADD CONSTRAINT product_sales_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_sales product_sales_sale_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_sales
    ADD CONSTRAINT product_sales_sale_id_foreign FOREIGN KEY (sale_id) REFERENCES public.sales(id) ON DELETE CASCADE;


--
-- Name: product_variant_images product_variant_images_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_variant_images
    ADD CONSTRAINT product_variant_images_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_variant_images product_variant_images_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_variant_images
    ADD CONSTRAINT product_variant_images_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.variants(id) ON DELETE CASCADE;


--
-- Name: related_variants related_variants_parent_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.related_variants
    ADD CONSTRAINT related_variants_parent_variant_id_foreign FOREIGN KEY (parent_variant_id) REFERENCES public.variants(id) ON DELETE CASCADE;


--
-- Name: related_variants related_variants_related_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.related_variants
    ADD CONSTRAINT related_variants_related_variant_id_foreign FOREIGN KEY (related_variant_id) REFERENCES public.variants(id) ON DELETE CASCADE;


--
-- Name: review_images review_images_review_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review_images
    ADD CONSTRAINT review_images_review_id_foreign FOREIGN KEY (review_id) REFERENCES public.reviews(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.variants(id) ON DELETE CASCADE;


--
-- Name: rich_contents rich_contents_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rich_contents
    ADD CONSTRAINT rich_contents_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.variants(id) ON DELETE CASCADE;


--
-- Name: rich_images rich_images_rich_content_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rich_images
    ADD CONSTRAINT rich_images_rich_content_id_foreign FOREIGN KEY (rich_content_id) REFERENCES public.rich_contents(id);


--
-- Name: role_has_permissions role_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: room_categories room_categories_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_categories
    ADD CONSTRAINT room_categories_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: room_categories room_categories_room_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_categories
    ADD CONSTRAINT room_categories_room_id_foreign FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON DELETE CASCADE;


--
-- Name: users users_group_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_group_id_foreign FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: variants variants_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.variants
    ADD CONSTRAINT variants_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

